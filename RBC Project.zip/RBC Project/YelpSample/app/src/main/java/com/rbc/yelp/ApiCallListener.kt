package com.rbc.yelp

import androidx.lifecycle.LiveData
import com.rbc.yelp.services.models.SearchResult

interface ApiCallListener {
    fun onstarted()
    fun onSuccess(searchResponse: LiveData<SearchResult>)
    fun onFailure(message:String)
}