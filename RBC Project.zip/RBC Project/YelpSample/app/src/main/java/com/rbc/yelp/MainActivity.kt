package com.rbc.yelp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.rbc.yelp.adapter.BusinessRecyclerAdapter
import com.rbc.yelp.services.models.Business
import com.rbc.yelp.services.models.Category
import com.rbc.yelp.services.models.GenericModel
import com.rbc.yelp.services.models.SearchResult
import com.rbc.yelp.viewmodel.MainActivityViewModel

class MainActivity : AppCompatActivity(), ApiCallListener, BusinessRecyclerAdapter.OnItemClickListener {

    lateinit var button: Button
    lateinit var locationEditText: EditText
    lateinit var searchTermEditText: EditText
    lateinit var businessRecycler: RecyclerView
    lateinit var businessRecyclerAdapter: BusinessRecyclerAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        button = findViewById(R.id.searchButton)
        locationEditText = findViewById(R.id.etSearchTerm)
        searchTermEditText = findViewById(R.id.etLocation)
        businessRecycler = findViewById(R.id.businessRecycler)
        businessRecycler.layoutManager = LinearLayoutManager(this)
        businessRecyclerAdapter = BusinessRecyclerAdapter(this)
        businessRecycler.setAdapter(businessRecyclerAdapter)

        val viewModel = ViewModelProvider(this).get(MainActivityViewModel::class.java)
        viewModel.apiCallListener = this

        button.setOnClickListener {
            viewModel.searchTerm = searchTermEditText.text.toString()
            viewModel.location = locationEditText.text.toString()
            viewModel.searchButtonclick()
        }
    }

    override fun onstarted() {
        showToast("Fetching Request...")
    }

    fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

    }

    override fun onSuccess(searchResponse: LiveData<SearchResult>) {
        var localListBusiness: List<Business> = ArrayList()
        var localListCategory: List<Category> = ArrayList()
        val generalArrayList = ArrayList<GenericModel>()
        searchResponse.observe(this, Observer { it ->
            val total = it.total
            val list = it.businesses
            val searchResultArrayList = ArrayList<SearchResult>()
            for (i in 1..total) {
                val searchResult = SearchResult(total, list)
                searchResultArrayList.add(searchResult)
            }

            for (i in searchResultArrayList.indices) {
                localListBusiness = searchResultArrayList[i].businesses
                for (k in 0 until localListBusiness.size) {
                    val business = localListBusiness[k]
                    val genericModelBusiness = GenericModel(business, null)
                    generalArrayList.add(genericModelBusiness)
                    localListCategory = business.categories
                    for (j in 0 until localListCategory.size) {
                        val category = localListCategory[j]
                        val genericModelCategory = GenericModel(null, category)
                        generalArrayList.add(genericModelCategory)
                    }
                }
            }
            businessRecyclerAdapter.updateSearchList(generalArrayList)
            showToast("Success...")
        })
    }

    override fun onFailure(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    override fun onItemClick(business: Business?) {
        val intent = Intent(this, SerachDetailsActivity::class.java)
        val bundle = Bundle()
        bundle.putSerializable("value", business)
        intent.putExtras(bundle)
        startActivity(intent)
    }


}