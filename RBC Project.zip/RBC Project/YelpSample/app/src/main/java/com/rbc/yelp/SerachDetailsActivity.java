package com.rbc.yelp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.rbc.yelp.services.models.Business;

public class SerachDetailsActivity extends AppCompatActivity {

    public ImageView businessImageView;
    public TextView tvName;
    public TextView tvCategory;
    public TextView tvRating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_serach_details);
        businessImageView = findViewById(R.id.businessImageView);
        tvName  = findViewById(R.id.tvName);
        tvRating = findViewById(R.id.tvRating);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        Business business = (Business) bundle.getSerializable("value");
        loadImageAndDetails(business);

    }

    public void loadImageAndDetails(Business business){

        tvName.setText(business.getName());
        String  rating = String.valueOf(business.getRating());
        tvRating.setText(rating);
        Glide.with(SerachDetailsActivity.this)
                .load(business.getImageURL())
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .into(businessImageView);
    }


}