package com.rbc.yelp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.rbc.yelp.R;
import com.rbc.yelp.services.models.Business;
import com.rbc.yelp.services.models.Category;
import com.rbc.yelp.services.models.GenericModel;

import java.util.ArrayList;

public class BusinessRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<GenericModel> genericModelArrayList;
    private String previousBusinessName = "";
    private final OnItemClickListener listener;


    public BusinessRecyclerAdapter(OnItemClickListener listener) {
        this.genericModelArrayList = new ArrayList<>();
        this.listener = listener;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rootView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_layout, parent, false);
        return new RecyclerViewHolder(rootView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        RecyclerViewHolder viewHolder = (RecyclerViewHolder) holder;


        GenericModel genericModel = genericModelArrayList.get(position);

        for (int i = position; i < genericModelArrayList.size(); i++) {
            Business business = genericModelArrayList.get(i).business;
            Category category = genericModelArrayList.get(i).category;
            if (business != null) {
                int categoryCount = business.getCategories().size();
                viewHolder.txtViewBusinessTitle.setVisibility(View.VISIBLE);
                viewHolder.btSelect.setVisibility(View.VISIBLE);
                viewHolder.txtViewCategoryTitle.setVisibility(View.GONE);
                viewHolder.txtViewBusinessTitle.setText(business.getName() + " (" + categoryCount + ")");

                break;
            } else {
                if (category != null) {
                    viewHolder.txtViewBusinessTitle.setVisibility(View.GONE);
                    viewHolder.btSelect.setVisibility(View.GONE);
                    viewHolder.txtViewCategoryTitle.setText("*" + category.getTitle());
                    break;
                }
            }
        }

        viewHolder.btSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(genericModelArrayList.get(holder.getAdapterPosition()).business);
            }
        });
    }

    @Override
    public int getItemCount() {
        return getItemSize();
    }

    public interface OnItemClickListener {
        void onItemClick(Business business);
    }

    private int getItemSize() {
        int items = genericModelArrayList.size();
        return items;
    }

    public void updateSearchList(final ArrayList<GenericModel> searchResultList) {
//        this.genericModelArrayList.clear();
        this.genericModelArrayList = searchResultList;
        notifyDataSetChanged();
    }

    class RecyclerViewHolder extends RecyclerView.ViewHolder {
        TextView txtViewCategoryTitle;
        TextView txtViewBusinessTitle;
        Button btSelect;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            txtViewCategoryTitle = itemView.findViewById(R.id.tvCategoryTitle);
            txtViewBusinessTitle = itemView.findViewById(R.id.tvBusinessTitle);
            btSelect = itemView.findViewById(R.id.btSelect);
        }
    }
}
