package com.rbc.yelp.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.rbc.yelp.services.YelpApi
import com.rbc.yelp.services.YelpRetrofit
import com.rbc.yelp.services.models.SearchResult
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class SearchRepository {

    fun searchBuisness(searchTerm: String, location: String): LiveData<SearchResult> {
        val serachResponse = MutableLiveData<SearchResult>()

        val apiService: YelpApi = YelpRetrofit().retrofitInstance.create(YelpApi::class.java)
        apiService.search(searchTerm, location)
                .enqueue(object : Callback<SearchResult> {
                    override fun onResponse(call: Call<SearchResult>, response: Response<SearchResult>) {

                        if (response.isSuccessful) {
                            serachResponse.value = response.body()
                        }
                    }

                    override fun onFailure(call: Call<SearchResult>, t: Throwable) {

                    }
                })
        return serachResponse
    }

}