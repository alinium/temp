package com.rbc.yelp.services.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Category implements Serializable {
    @SerializedName("alias")
    private String alias;
    @SerializedName("title")
    private String title;

    public String getAlias() {
        return alias;
    }

    public String getTitle() {
        return title;
    }
}
