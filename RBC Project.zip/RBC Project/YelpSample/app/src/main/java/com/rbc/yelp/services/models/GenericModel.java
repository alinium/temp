package com.rbc.yelp.services.models;

public class GenericModel {

    public Business business;
    public Category category;

    public GenericModel(Business business, Category category) {
        this.business = business;
        this.category = category;
    }
}
