package com.rbc.yelp.services.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SearchResult {
    @SerializedName("total")
    private int total;
    @SerializedName("businesses")
    private List<Business> businesses;

    public SearchResult(int total, List<Business> businesses) {
        this.total = total;
        this.businesses = businesses;
    }

    public int getTotal() {
        return total;
    }

    public List<Business> getBusinesses() {
        return businesses;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public void setBusinesses(List<Business> businesses) {
        this.businesses = businesses;
    }
}
