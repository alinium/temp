package com.rbc.yelp.viewmodel

import androidx.lifecycle.ViewModel
import com.rbc.yelp.ApiCallListener
import com.rbc.yelp.repository.SearchRepository

class MainActivityViewModel : ViewModel() {
    var searchTerm : String? = null
    var location : String? = null
    var apiCallListener: ApiCallListener? = null

    fun searchButtonclick(){

        apiCallListener?.onstarted()
        if (location.isNullOrEmpty()){
            apiCallListener?.onFailure("Location should not be empty!!")
            return
        }

        val searchResponse = SearchRepository().searchBuisness(searchTerm!!,location!!)
        apiCallListener?.onSuccess(searchResponse)




    }
//    val intent = Intent(this, SearchResultActivity::class.java).putExtra("response",searchResponse)
//    val args = Bundle()
//    args.putSerializable("ARRAYLIST", searchResponse)
//    intent.putExtra("BUNDLE", args)
//    startActivity(intent)

}